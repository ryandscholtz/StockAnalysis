# Service layer abstractions
