# Core application components
