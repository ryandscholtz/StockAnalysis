"""
Authentication module for JWT-based authentication
"""
